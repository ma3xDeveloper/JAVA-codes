package com.example.nicepuzzle.nicepuzzle;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Toast;

import static com.example.nicepuzzle.nicepuzzle.R.styleable.View;

public class OptionsActivity extends ActivityExtended implements FragmentMenuOptions1.IFragmentButtonClicked {

    public FragmentMenuOptions2 fragment2;
    public FragmentMenuOptionsDisplayFragments fragmentDisplay;

    private DbManager dbManager;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_options);

        dbManager = new DbManager(this);
        dbManager.getWritableDatabase();

        //TODO bug with hide option
        fragment2 = (FragmentMenuOptions2)getFragmentManager().findFragmentById(R.id.fragment2);
    }

    @Override
    public void onButtonClicked() {
        if (fragment2 !=null) {
            fragmentDisplay = new FragmentMenuOptionsDisplayFragments();

            getFragmentManager().beginTransaction().add(R.id.fragmentContainer, fragmentDisplay).commit();
        }
    }

    @Override
    public void onRemoveButtonClicked() {
        getFragmentManager().beginTransaction().remove(fragmentDisplay).commit();

    }

    public void onRadioButtonClicked(android.view.View view) {
        if (view.getId() == R.id.checkBoxGameDurationOption1){

            GameOption gameOption = new GameOption(1, 500000);
            dbManager.updateGameOption(gameOption);
            Toast.makeText(this, "New Options Saved: 5 min", Toast.LENGTH_SHORT).show();
        }
        if (view.getId() == R.id.checkBoxGameDurationOption2){
            GameOption gameOption = new GameOption(1, 1500000);
            dbManager.updateGameOption(gameOption);
            Toast.makeText(this, "New Options Saved: 15 min", Toast.LENGTH_SHORT).show();
        }
        if (view.getId() == R.id.checkBoxGameDurationOption3){
            GameOption gameOption = new GameOption(1, 2000000);
            dbManager.updateGameOption(gameOption);
            Toast.makeText(this, "New Options Saved: 20 min", Toast.LENGTH_SHORT).show();
        }

        //TODO Bug with multiple DB update

    }
}
