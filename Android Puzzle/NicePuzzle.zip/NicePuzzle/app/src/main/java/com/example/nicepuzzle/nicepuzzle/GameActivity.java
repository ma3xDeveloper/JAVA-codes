package com.example.nicepuzzle.nicepuzzle;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;

public class GameActivity extends ActivityExtended implements View.OnClickListener {
    public Intent gameLoopServiceIntent;
    public static Boolean isGameOn;

    private final String TAG_FOR_DEBUG = GameActivity.class.getSimpleName();
    //private final String NORMALC_CELL_BACKGROUND_COLOR = "";
   // private final String ZERO_CELL_BACKGROUND_COLOR = "";

    private TextView gameTimeCounterText;
    private TextView movesCounterText;
    public static Integer movesCounter = 0;
    private TextView movesFeedbackCommentText;
    private Button[] buttonsArrey = new Button[9];
    private Boolean isMoveBad = false;
    private static final Integer[] thePerfectDoneCelsArrey = new Integer[] {0,1,2,3,4,5,6,7,8};
    private ArrayList<Integer> currentGameCellsArrey = new ArrayList<Integer>();
    private GameReciever gameReciever;
    private long gameDuration = 50000;

    private DbManager dbManager;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        dbManager = new DbManager(this);
        dbManager.getWritableDatabase();

        startGameLoopService();
        registerRecieverForBroadcast();

        this.buttonsArrey[0] = (Button) findViewById(R.id.button1);
        this.buttonsArrey[1] = (Button) findViewById(R.id.button2);
        this.buttonsArrey[2] = (Button) findViewById(R.id.button3);
        this.buttonsArrey[3] = (Button) findViewById(R.id.button4);
        this.buttonsArrey[4] = (Button) findViewById(R.id.button5);
        this.buttonsArrey[5] = (Button) findViewById(R.id.button6);
        this. buttonsArrey[6] = (Button) findViewById(R.id.button7);
        this.buttonsArrey[7] = (Button) findViewById(R.id.button8);
        this.buttonsArrey[8] = (Button) findViewById(R.id.button0);

        for (int i = 0; i < 9; i++) {
            this.buttonsArrey[i].setOnClickListener(this);
        }

        this.movesCounterText = (TextView) findViewById(R.id.moveCountertextView);
        this.movesFeedbackCommentText = (TextView) findViewById(R.id.commentTextView);
        this.gameTimeCounterText = (TextView) findViewById(R.id.timerTextView);

        for(int i=0; i<9; i++)
        {
            this.currentGameCellsArrey.add(i);
        }

        // new random game cells array
        Collections.shuffle(this.currentGameCellsArrey);

        //initial draw the game grid with burrons
        updateGameGridWithButtons();
        displayTimeCounter();
    }

    @Override
    public void onClick(View v) {

        makeMoveDuringGameEngineLogic((Button) v);
    }
    public void registerRecieverForBroadcast(){
        gameReciever = new GameReciever();

        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("android.intent.action.DATE_CHANGED");
        registerReceiver(gameReciever, intentFilter);
    }

    public void unRegisterRecieverForBroadcast(){
        if(gameReciever != null){
            unregisterReceiver(gameReciever);
        }
    }

    private void startGameLoopService(){
        gameLoopServiceIntent = new Intent(this, GameLoopService.class);
        startService(gameLoopServiceIntent);
    }

    private void stopGameLoopService(){
        if (gameLoopServiceIntent == null)
        {
            gameLoopServiceIntent = new Intent(this, GameLoopService.class);
        }
        stopService(gameLoopServiceIntent);
    }


    private void displayTimeCounter() {
        try{
            GameOption gameOptionsFromDB = dbManager.getGameOption(1);
            this.gameDuration = gameOptionsFromDB.get_gameDuration();
        }
        catch (Exception ex){
            //TODO log the Exception
        }

        new CountDownTimer(this.gameDuration, 1000) {

            public void onTick(long gameDurationValue) {

                //Log.d(TAG_FOR_DEBUG, "gameDurationValue = " + gameDurationValue );

                long secondsLeft = gameDurationValue / 1000;
                long thirtySeconds = 10000 / 1000;
                gameTimeCounterText.setText(secondsLeft + " sec");

                if (secondsLeft <= thirtySeconds){
                    gameTimeCounterText.setTextColor(Color.parseColor("#ff0000"));
                }
                else{
                    gameTimeCounterText.setTextColor(Color.parseColor("#3399ff"));
                }


            }
            public void onFinish() {
                gameTimeCounterText.setText("0 sec");
                //Log.d(TAG_FOR_DEBUG, "SCORE = " + getMovesCounter() );
                displayGameOverAlertDialogMessage("Time's up!", "Your score is: " + GameActivity.movesCounter);
                stopGameLoopService();
                unRegisterRecieverForBroadcast();
            }
        }.start();
    }

    private int findPositionInCurrentGameCellsArrey(int element)
    {
        int i=0;
        for(i=0; i<9; i++)
        {
            if(currentGameCellsArrey.get(i) == element)
            {
                break;
            }
        }
        return i;
    }

    private void makeMoveDuringGameEngineLogic(final Button button) {

        if(this.isGameOn == true) {
            this.isMoveBad = true;
            int currentButtonNumber, currentButtonPositionInArrey, zeroButtentPositonInArrey;

            currentButtonNumber = Integer.parseInt((String) button.getText());
            currentButtonPositionInArrey = findPositionInCurrentGameCellsArrey(currentButtonNumber);
            zeroButtentPositonInArrey = findPositionInCurrentGameCellsArrey(0);

            switch (zeroButtentPositonInArrey) {
                case (0):
                    if (currentButtonPositionInArrey == 1 || currentButtonPositionInArrey == 3)
                        this.isMoveBad = false;
                    break;
                case (1):
                    if (currentButtonPositionInArrey == 0 || currentButtonPositionInArrey == 2 || currentButtonPositionInArrey == 4)
                        this.isMoveBad = false;
                    break;
                case (2):
                    if (currentButtonPositionInArrey == 1 || currentButtonPositionInArrey == 5)
                        this.isMoveBad = false;
                    break;
                case (3):
                    if (currentButtonPositionInArrey == 0 || currentButtonPositionInArrey == 4 || currentButtonPositionInArrey == 6)
                        this.isMoveBad = false;
                    break;
                case (4):
                    if (currentButtonPositionInArrey == 1 || currentButtonPositionInArrey == 3 || currentButtonPositionInArrey == 5 || currentButtonPositionInArrey == 7)
                        this.isMoveBad = false;
                    break;
                case (5):
                    if (currentButtonPositionInArrey == 2 || currentButtonPositionInArrey == 4 || currentButtonPositionInArrey == 8)
                        this.isMoveBad = false;
                    break;
                case (6):
                    if (currentButtonPositionInArrey == 3 || currentButtonPositionInArrey == 7)
                        this.isMoveBad = false;
                    break;
                case (7):
                    if (currentButtonPositionInArrey == 4 || currentButtonPositionInArrey == 6 || currentButtonPositionInArrey == 8)
                        isMoveBad = false;
                    break;
                case (8):
                    if (currentButtonPositionInArrey == 5 || currentButtonPositionInArrey == 7)
                        isMoveBad = false;
                    break;
            }

            if (this.isMoveBad == false) {
                this.currentGameCellsArrey.remove(currentButtonPositionInArrey);
                this.currentGameCellsArrey.add(currentButtonPositionInArrey, 0);
                this.currentGameCellsArrey.remove(zeroButtentPositonInArrey);
                this.currentGameCellsArrey.add(zeroButtentPositonInArrey, currentButtonNumber);

                updateGameGridWithButtons();
                updateCurrentMoveFeedbackComment();
                updateMovesCounter();
            }

            if (isGameWon() == true) {
                //this.movesFeedbackCommentText.setText("You win!");
                displayGameOverAlertDialogMessage("You win!", "Your score is: " + GameActivity.movesCounter);
                stopGameLoopService();
                unRegisterRecieverForBroadcast();
            }
        }
    }

    private void updateCurrentMoveFeedbackComment() {

        if(this.isMoveBad == true) {
            this.movesFeedbackCommentText.setText(R.string.bad_move);
            this.movesFeedbackCommentText.setTextColor(Color.parseColor("#ff0000"));
        }
            else {
            this.movesFeedbackCommentText.setText(R.string.ok_move);
            this.movesFeedbackCommentText.setTextColor(Color.parseColor("#008000"));
        }
    }

    private void updateMovesCounter() {
        if (this.isMoveBad == false)
        {
            this.movesCounter++;
        }
        this.movesCounterText.setText("Moves: " + this.movesCounter);
    }

    private Boolean isGameWon() {
        for(int i=0; i<9; i++) {
            if(this.currentGameCellsArrey.get(i) != this.thePerfectDoneCelsArrey[i])
            {
                return false;
            }
        }
        return true;
    }


    private String returnTheCorrectButtonBackgroundColor(Integer number) {
        if (number == 0){
            return "#b36b00";
        }

        //TODO - constants or image links
        return "#ffe0b3";
    }

    private void updateGameGridWithButtons()
    {
        for(int i=0; i<9; i++)
        {
            int numberToDisplay= this.currentGameCellsArrey.get(i);
            this.buttonsArrey[i].setText(String.valueOf(numberToDisplay));
            this.buttonsArrey[i].setBackgroundColor(Color.parseColor(returnTheCorrectButtonBackgroundColor(numberToDisplay)));
        }
    }

    public void displayGameOverAlertDialogMessage(String alertMsgTitle, String alertMsgBody)
    {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        // set title
        alertDialogBuilder.setTitle(alertMsgTitle);

        // set dialog message
        alertDialogBuilder
                .setMessage(alertMsgBody + ". Do you whant to SAVE this Score?")
                .setCancelable(false)
                .setPositiveButton("No",new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog,int id) {
                dialog.cancel();
            }
        })
                .setNegativeButton("Yes",new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog,int id) {
                        //TODO save score to DB
                        dialog.cancel();
                    }
                });

        // create alert dialog
        AlertDialog alertDialog = alertDialogBuilder.create();

        // show it
        alertDialog.show();
    }

    @Override
    protected void onPause() {
        super.onPause();
        GameActivity.this.finish();
    }

    @Override
    protected void onStop() {
        super.onStop();
        GameActivity.this.finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        GameActivity.this.finish();
    }

    //TODO Bug with multiple Views running on background
}
