package com.example.nicepuzzle.nicepuzzle;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.widget.Toast;

public class GameLoopService extends Service {

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        GameActivity.isGameOn = true;
        //Toast.makeText(this, "Game started", Toast.LENGTH_LONG).show();

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        return super.onStartCommand(intent, flags, startId);

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        GameActivity.isGameOn = false;
       // Toast.makeText(this, "Game Over: " + GameActivity.movesCounter, Toast.LENGTH_LONG).show();
    }
}
