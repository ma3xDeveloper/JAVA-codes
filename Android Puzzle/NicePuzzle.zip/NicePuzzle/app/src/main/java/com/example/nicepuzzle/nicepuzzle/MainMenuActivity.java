package com.example.nicepuzzle.nicepuzzle;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class MainMenuActivity extends ActivityExtended implements View.OnClickListener{

    Button startGameButton, highScoreButton, optionButton, quitButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        startGameButton = (Button)findViewById(R.id.buttonStartGame);
        startGameButton.setOnClickListener(this);

        highScoreButton = (Button)findViewById(R.id.buttonHighScore);
        highScoreButton.setOnClickListener(this);

        optionButton = (Button)findViewById(R.id.buttonOptions);
        optionButton.setOnClickListener(this);

        quitButton = (Button)findViewById(R.id.buttonQuit);
        quitButton.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.buttonStartGame)
        {
            Intent intentStartGame = new Intent(MainMenuActivity.this, GameActivity.class);
            startActivity(intentStartGame);
        }

        if (v.getId() == R.id.buttonHighScore)
        {
            Intent intentHighScore = new Intent(MainMenuActivity.this, HighScoreActivity.class);
            startActivity(intentHighScore);
        }

        if (v.getId() == R.id.buttonOptions)
        {
            Intent intentOptions = new Intent(MainMenuActivity.this, OptionsActivity.class);
            startActivity(intentOptions);
        }

        if (v.getId() == R.id.buttonQuit)
        {
            finish();
        }
    }



}
