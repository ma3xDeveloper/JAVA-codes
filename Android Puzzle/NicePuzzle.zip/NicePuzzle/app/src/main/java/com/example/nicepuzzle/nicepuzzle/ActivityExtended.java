package com.example.nicepuzzle.nicepuzzle;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;

public class ActivityExtended extends AppCompatActivity {
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main,menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId() == R.id.NewGameItem)
        {
            Intent intentStartGame = new Intent(this, GameActivity.class);
            startActivity(intentStartGame);
        }
        if(item.getItemId() == R.id.HichScoreItem)
        {
            Intent intentHighScore = new Intent(this, HighScoreActivity.class);
            startActivity(intentHighScore);
        }

        if(item.getItemId() == R.id.OptionsItem)
        {
            Intent intentOptions = new Intent(this, OptionsActivity.class);
            startActivity(intentOptions);
        }

        return true;
    }
}
