package com.example.nicepuzzle.nicepuzzle;

import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

public class FragmentMenuOptions1 extends Fragment implements View.OnClickListener{

    public interface IFragmentButtonClicked{
        public void onButtonClicked();
        public void onRemoveButtonClicked();

    }

    Button buttonShowTimerOptions, buttonHideTimerOptions;

    IFragmentButtonClicked onButtonClicked;

    @Override
    public void onAttach(Context context) {

        super.onAttach(context);

        onButtonClicked = (IFragmentButtonClicked)context;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
         View view = inflater.inflate(R.layout.menu_options_fragment_1, container, false);

        buttonShowTimerOptions = (Button) view.findViewById(R.id.buttonShowTimerOptions);
        buttonShowTimerOptions.setOnClickListener(this);

        buttonHideTimerOptions = (Button) view.findViewById(R.id.buttonHideTimerOptions);
        buttonHideTimerOptions.setOnClickListener(this);

        return view;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        buttonShowTimerOptions.setOnClickListener(null);
        buttonHideTimerOptions.setOnClickListener(null);
    }

    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.buttonShowTimerOptions){
            if (onButtonClicked != null) {
                onButtonClicked.onButtonClicked();
            }
        }
        if(v.getId() == R.id.buttonHideTimerOptions){
            if (onButtonClicked != null) {
                onButtonClicked.onRemoveButtonClicked();
            }
        }
    }
}
