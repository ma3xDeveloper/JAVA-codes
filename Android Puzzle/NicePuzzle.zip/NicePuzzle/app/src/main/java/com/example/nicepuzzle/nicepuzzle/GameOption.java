package com.example.nicepuzzle.nicepuzzle;

public class GameOption {

    private int _id;
    private long _gameDuration;

    public GameOption(int id, long gameDuration){
        this.set_id(id);
        this.set_gameDuration(gameDuration);
    }

    public long get_id(){
        return _id;
    }


    public void set_id(int id){

        if (id > 0)  {
            this._id = id;
        }
    }

    public long get_gameDuration(){
        return _gameDuration;
    }


    public void set_gameDuration(long gameDuration){

        if (gameDuration > 0) {
            this._gameDuration = gameDuration;
        }
    }


}
