package com.example.nicepuzzle.nicepuzzle;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DbManager extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "NicePuzzleDB";
    private static final String TABLE_NAME_GAME_OPTION = "GameOption";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_GAME_DURATION = "gameDuration";


    public DbManager(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_SQL_QUERY = "CREATE TABLE " + TABLE_NAME_GAME_OPTION + " (" + COLUMN_ID + " INTEGER PRIMARY KEY," + COLUMN_GAME_DURATION + " TEXT" + ")";
        db.execSQL(CREATE_SQL_QUERY);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME_GAME_OPTION);
        onCreate(db);
        GameOption defeaultGameOption = new GameOption(1, 500000);
       // addGameOption(defeaultGameOption);
    }

    public void addGameOption(GameOption gameOption){
        SQLiteDatabase currentDB = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_ID, String.valueOf(gameOption.get_id()));
        values.put(COLUMN_GAME_DURATION, String.valueOf(gameOption.get_gameDuration()));

        currentDB.insert(TABLE_NAME_GAME_OPTION, null, values);
        currentDB.close();
    }

    public void updateGameOption(GameOption gameOption){
        SQLiteDatabase currentDB = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_ID, String.valueOf(gameOption.get_id()));
        values.put(COLUMN_GAME_DURATION, String.valueOf(gameOption.get_gameDuration()));

        String SQL_SELECTOR = COLUMN_ID + " LIKE ?";
        String[] SQL_SELECTRO_ARGS = {"id"};

        currentDB.update(TABLE_NAME_GAME_OPTION, values, SQL_SELECTOR, SQL_SELECTRO_ARGS);
        currentDB.close();
    }


    public GameOption getGameOption(int id){
        SQLiteDatabase currentDB = this.getWritableDatabase();
        Cursor cursorIterators = currentDB.query(TABLE_NAME_GAME_OPTION, new String[]{COLUMN_ID, COLUMN_GAME_DURATION}, COLUMN_ID + "=?", new String[]{String.valueOf(id)}, null, null, null, null);
        if (cursorIterators !=null){
            cursorIterators.moveToFirst();
            GameOption gameOptionFromDB = new GameOption(Integer.parseInt(cursorIterators.getString(0)), Long.parseLong(cursorIterators.getString(1)));
            //String value = cursorIterators.getColumnName(1);
            return gameOptionFromDB;
        }
        currentDB.close();
        return null;
    }
}
